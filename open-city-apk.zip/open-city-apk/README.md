# Open City – Android APK

## Build on GitHub (no Android Studio needed)
1. Create a new GitHub repository and upload everything in this folder
   (the `.github` folder and the `android-app` folder must be at the top level).
2. Open the **Actions** tab. The "Build APK" workflow runs on every push.
3. When it finishes, open the run and download **open-city-debug-apk** from "Artifacts".
4. Copy `app-debug.apk` to your phone and install it (allow "install unknown apps").

## Notes
- The phone needs internet the first time the game loads three.js from the CDN.
- The game lives in `android-app/app/src/main/assets/index.html`.
  The character model is `quaternius_cc0-male-character-1352.glb` in the same folder.
- This is a debug build for testing. A Play Store release needs a signing key
  and `gradle :app:assembleRelease`.
